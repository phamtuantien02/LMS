import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showmaterial',
  templateUrl: './showmaterial.component.html',
  styles: [
  ]
})
export class ShowmaterialComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
