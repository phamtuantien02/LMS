import { Component, OnInit, Input } from '@angular/core';
import { TestQuestionService } from '../../service/managetestquestion.service';

@Component({
  selector: 'app-addeditquestion',
  templateUrl: './addeditquestion.component.html',
  styles: [
  ]
})
export class AddeditquestionComponent implements OnInit {


  constructor(private service:TestQuestionService) { }
  @Input() QuestionParam:any;

  QuestionId:string = "";
  Question:string = "";
  isNew:boolean = false;
  
  ngOnInit(): void {
    this.QuestionId = this.QuestionParam.TestQuestionId;
    this.Question = this.QuestionParam.Question;
    if(this.QuestionId == "0")
    {
      this.isNew =  true;
    }
  }

  addQuestion()
  {
    var val =  {QuestionId:this.QuestionId,
                Question:this.Question};
    this.service.addQuestion(val).subscribe(res=>{
      alert(res.toString());
    })
  }

  updateQuestion()
  {
    var val =  {QuestionId:this.QuestionId,
                Question:this.Question};
    this.service.updateQuestion(val).subscribe(res=>{
      alert(res.toString());
    })
  }

}
