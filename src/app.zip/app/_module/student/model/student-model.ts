export class StudentModel {
    public StudID? : number;
    public UserName? : string;
    public PassWord? : string;
    public FirstName? : string;
    public LastName? : string;
    public Email? : string;

    constructor(StudID?: number, UserName? : string, PassWord?: string, FirstName? : string, LastName? : string, Email? : string)
    {
        this.StudID = StudID;
        this.UserName = UserName;
        this.PassWord = PassWord;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.Email = Email;
    }
    
    
}
