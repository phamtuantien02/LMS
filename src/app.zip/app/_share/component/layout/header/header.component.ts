import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html'
})

export class HeaderComponent implements OnInit {
  isLoggedIn :boolean=false;

  constructor() {
    if(localStorage.getItem("UserLogin") != "")
    {
      this.isLoggedIn = true;
    }
  }
 
  ngOnInit() {
    if(localStorage.getItem("UserLogin") != "")
    {
      this.isLoggedIn = true;
    }
    }
}
