import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class homeService {
readonly APIUrl = "http://localhost:60769/api"

  constructor(private http:HttpClient) { }

  getLogin(val:any):Observable<any[]>
  {
    return this.http.post<any>(this.APIUrl+'/Student/login',val);
  }
}
