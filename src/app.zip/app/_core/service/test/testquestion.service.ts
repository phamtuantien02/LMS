import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class TestquestionService {
  readonly APIUrl = "http://localhost:60769/api"

  constructor(private http : HttpClient) { }

  getQuestionJson()
  {
    return this.http.get<any>("assets/questions.json");
  }

  getAllQuestionsForTest(val:any)
  {
    return this.http.post<any>(this.APIUrl+'/Test/GetTestByTestID',val);
  }
}
