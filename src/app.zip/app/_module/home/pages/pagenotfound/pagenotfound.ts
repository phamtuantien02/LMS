import { Component } from '@angular/core';
@Component({
  selector: 'app-pagenotfound',
  templateUrl: './pagenotfound.html'
})
export class PageNotFound {
  
}
