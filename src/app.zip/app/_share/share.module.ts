import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { HeaderLoggedinComponent } from './component/layout/header/header-loggedin.component';
import { HeaderNotLoginComponent } from './component/layout/header/header-not-login.component';
import { HeaderComponent } from './component/layout/header/header.component';
import { FooterComponent } from './component/layout/footer/footer.component';
@NgModule({
  imports: [
    CommonModule,
    RouterModule
  ],
  declarations: [
    HeaderLoggedinComponent,
    HeaderNotLoginComponent,
    HeaderComponent,
    FooterComponent
  ],
  exports: [
    CommonModule,
    HeaderLoggedinComponent,
    HeaderNotLoginComponent,
    HeaderComponent,
    FooterComponent
  ]
})

export class SharedModule {
}
