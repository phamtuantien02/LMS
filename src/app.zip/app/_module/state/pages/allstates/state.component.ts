import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-state',
  templateUrl: './state.component.html'
})
export class ShowAllStateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
