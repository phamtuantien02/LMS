import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AllStudentComponent } from './pages/allstudents/student.component';
import { StudentdashboardComponent } from './pages/studentdashboard/studentdashboard.component';
const routes: Routes = [
  {
     path: '',component: AllStudentComponent,
  },
  {
     path:'student',component:AllStudentComponent,
  },
  {
    path:'dashboard',component:StudentdashboardComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StudentRoutingModule {}
