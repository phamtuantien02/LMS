import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class testService {
readonly APIUrl = "http://localhost:60769/api"

  constructor(private http:HttpClient) { }
  AssignQuestionToTest(val:any):Observable<any[]>
  {
    return this.http.post<any>(this.APIUrl+'/Test/AssignQuestion',val);
  }
  gettestList():Observable<any[]>
  {
    return this.http.get<any>(this.APIUrl+'/Test');
  }
  addtest(val:any)
  {
    return this.http.post(this.APIUrl+'/Test',val);
  }
  updatetest(val:any)
  {
    return this.http.put(this.APIUrl+'/Test',val);
  }

  deletetest(val:any)
  {
    return this.http.delete(this.APIUrl+'/Test/'+val);
  }

  getAlltestNames():Observable<any[]>
  {
    return this.http.get<any[]>(this.APIUrl+'/GetAlltestNames');
  }
}
