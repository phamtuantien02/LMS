import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-student',
  templateUrl: './student.component.html'
})
export class AllStudentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
