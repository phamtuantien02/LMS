import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info',
  templateUrl: './test.component.html',
  styles: [
  ]
})
export class TestInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
