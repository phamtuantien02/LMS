import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'allCourses',
  templateUrl: './course.component.html'
})
export class AllCoursePage implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
