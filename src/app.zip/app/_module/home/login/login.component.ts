import { Component, OnInit } from '@angular/core';
import { homeService } from '../service/home.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styles: [
  ]
})
export class LoginComponent implements OnInit {

  constructor(private service: homeService, private route: Router) { }
  
  UserInfo : any=[];
  UserName : string = "";
  PassWord : string = "";

  ngOnInit(): void {
  }

  onSubmit()
  {
    var val = {UserName:this.UserName,
      PassWord:this.PassWord};
      console.log("Here");
      this.service.getLogin(val).subscribe(res=>{
        this.UserInfo = res;
        //alert(this.UserInfo[0].StudID);
        localStorage.setItem('UserLogin',JSON.stringify(this.UserInfo[0].StudID));
        //this.route.navigateByUrl("/");
        this.route.navigate(['/student/dashboard'])
          .then(() => {
          window.location.reload();
            });
    })
    //localStorage.setItem('UserLogin',JSON.stringify(val));
  }

}
