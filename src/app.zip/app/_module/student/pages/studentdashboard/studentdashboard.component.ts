import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentdashboard',
  templateUrl: './studentdashboard.component.html',
  styles: [
  ]
})
export class StudentdashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
