import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowAlltestComponent } from './pages/test.component';
import { ShowAllTestQuestionPage } from './pages/showallquestions/showallquestions.component';
const routes: Routes = [
  {
     path: '',
     component: ShowAlltestComponent,
  },
  {
     path:'test',
     component:ShowAlltestComponent,
  },
  {path:'testquestion', component:ShowAllTestQuestionPage}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class testRoutingModule {}
