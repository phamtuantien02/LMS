import { Component, OnInit } from '@angular/core';
import { StudentService } from '../service/student.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styles: [
  ]
})
export class DashboardComponent implements OnInit {

  constructor(private service: StudentService) { }
  studentCourse: any = [];
  
  ngOnInit(): void {
    var val = {StudID:localStorage.getItem("UserLogin")}

    this.service.getStudentCourseList(val).subscribe(data=>{

      this.studentCourse = data;
      console.log(this.studentCourse);
    });
  }

}
