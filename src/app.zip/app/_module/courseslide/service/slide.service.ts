import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SlideService {
readonly APIUrl = "http://localhost:60769/api"

  constructor(private http:HttpClient) { }

  getSlideList():Observable<any[]>
  {
    return this.http.get<any>(this.APIUrl+'/Slide');
  }
  addSlide(val:any)
  {
    return this.http.post(this.APIUrl+'/Slide',val);
  }
  updateSlide(val:any)
  {
    return this.http.put(this.APIUrl+'/Slide',val);
  }

  deleteSlide(val:any)
  {
    return this.http.delete(this.APIUrl+'/Slide/'+val);
  }

  getAllSlideNames():Observable<any[]>
  {
    return this.http.get<any[]>(this.APIUrl+'/GetAllSlideNames');
  }
}
