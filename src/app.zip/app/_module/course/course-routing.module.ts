import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AllCoursePage } from './pages/course.component';
import { ShowmaterialComponent } from './pages/showmaterial/showmaterial.component';
import { ShowtestwelcomeComponent } from './pages/showtestwelcome/showtestwelcome.component';
import { ShowCourseComponent } from './showcourse/show-course.component';
import { AddEditCourseComponent } from './add-edit-course/add-edit-course.component';
const routes: Routes = [
  {
     path: '',
     component: AllCoursePage,
  },
  {
     path:'courses',
     component:AllCoursePage,
  },
  {
    path:'showmaterial',
    component:ShowmaterialComponent,
  },
  {
    path:'showmaterial/:CourseID',
    component:ShowmaterialComponent,
  },
  {
    path:'showtestwelcome',
    component:ShowtestwelcomeComponent,
  },
  {
    path:'showtestwelcome/:CourseID',
    component:ShowtestwelcomeComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CourseRoutingModule {}
