import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-Slide',
  templateUrl: './Slide.component.html'
})
export class ShowAllSlidePages implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
