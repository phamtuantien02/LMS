import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
readonly APIUrl = "http://localhost:60769/api"

  constructor(private http:HttpClient) { }
  AssignSlideToCourse(val:any)
  {
    return this.http.post(this.APIUrl+'/Course/AssignSlideToCourse',val);
  }
  AssignTestToCourse(val:any)
  {
    return this.http.post(this.APIUrl+'/Course/AssignTestToCourse',val);
  }
  getCourseList():Observable<any[]>
  {
    return this.http.get<any>(this.APIUrl+'/Course');
  }
  addCourse(val:any)
  {
    return this.http.post(this.APIUrl+'/Course',val);
  }
  updateCourse(val:any)
  {
    return this.http.put(this.APIUrl+'/Course',val);
  }

  deleteCourse(val:any)
  {
    return this.http.delete(this.APIUrl+'/Course/'+val);
  }

  getAllCourseNames():Observable<any[]>
  {
    return this.http.get<any[]>(this.APIUrl+'/GetAllCourses');
  }
  
  getCourseSlideByID(val:any):Observable<any[]>
  {
    return this.http.post<any[]>(this.APIUrl+'/course/getCourseSlideByID',val);
  }

  getTestInfoByCourseID(val:any):Observable<any[]>
  {
    return this.http.post<any>(this.APIUrl+'/Test/getTestInfoByCourseID',val);
  }
}
