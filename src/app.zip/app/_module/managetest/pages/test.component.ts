import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showAllTest',
  templateUrl: './test.component.html'
})
export class ShowAlltestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
