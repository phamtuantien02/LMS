import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TestQuestionService {
readonly APIUrl = "http://localhost:60769/api"

  constructor(private http:HttpClient) { }


  getTestAnswerList(val:any):Observable<any[]>
  {
    return this.http.post<any>(this.APIUrl+'/TestQuestion/GetTestAnswers',val);
  }
  getTestQuestionList():Observable<any[]>
  {
    return this.http.get<any>(this.APIUrl+'/TestQuestion');
  }
  addQuestion(val:any)
  {
    return this.http.post(this.APIUrl+'/TestQuestion',val);
  }
  addAnswer(val:any)
  {
    return this.http.post(this.APIUrl+'/TestQuestion/InsertAnser',val);
  }
  updateQuestion(val:any)
  {
    return this.http.put(this.APIUrl+'/TestQuestion',val);
  }

  deletetestquestion(val:any)
  {
    return this.http.delete(this.APIUrl+'/TestQuestion/'+val);
  }
}
