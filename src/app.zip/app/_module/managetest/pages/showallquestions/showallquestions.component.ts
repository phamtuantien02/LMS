import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showallquestions',
  templateUrl: './showallquestions.component.html',
  styles: [
  ]
})
export class ShowAllTestQuestionPage implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
