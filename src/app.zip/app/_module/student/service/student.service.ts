import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { StudentModel } from '../model/student-model';
@Injectable({
  providedIn: 'root'
})
export class StudentService {
readonly APIUrl = "http://localhost:60769/api"

  constructor(private http:HttpClient) { }

  AssignCourseToStudent(val:any)
  {
    return this.http.post<any>(this.APIUrl+'/Student/assignCourse',val);
  }

  getStudentList():Observable<StudentModel[]>
  {
    return this.http.get<StudentModel[]>(this.APIUrl+'/Student');
  }
  addStudent(val:any)
  {
    return this.http.post(this.APIUrl+'/Student',val);
  }
  updateStudent(val:any)
  {
    return this.http.put(this.APIUrl+'/Student',val);
  }
  deleteStudent(val:any)
  {
    return this.http.delete(this.APIUrl+'/Student/'+val);
  }

  getStudentCourseList(val:any):Observable<any[]>
  {
    return this.http.post<any>(this.APIUrl+'/Student/getStudentCourse',val);
  }
  getStudentbyID(val:any):Observable<any[]>
  {
    return this.http.post<any>(this.APIUrl+'/Student/getStudentInfoByID',val);
  }
}
