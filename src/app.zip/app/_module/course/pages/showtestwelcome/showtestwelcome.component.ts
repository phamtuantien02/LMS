import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showtestwelcome',
  templateUrl: './showtestwelcome.component.html',
  styles: [
  ]
})
export class ShowtestwelcomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
