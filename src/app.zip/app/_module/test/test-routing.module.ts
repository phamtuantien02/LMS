import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TestInfoComponent } from './pages/testinfo/test.component';
import { QuestionComponent } from './question/question.component';
const routes: Routes = [
  {
     path:'',component:TestInfoComponent,
  },
  {
    path:'test', component:TestInfoComponent,
 },
 {
   path:'testquestion', component:QuestionComponent,
},
{
  path:'testquestion/:TestID', component:QuestionComponent,
}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TestRoutingModule {}
