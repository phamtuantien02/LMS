import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from 'src/app/_module/student/service/student.service';

@Component({
    selector: 'app-header-loggedin',
    templateUrl: './header-loggedin.component.html'
})

export class HeaderLoggedinComponent implements OnInit{
  constructor(private route: Router, private service: StudentService) { }
  student:any;
  /********************************************************************************/
  onLogout() {
    localStorage.setItem("UserLogin","");
    this.route.navigateByUrl("/");
  }
    ngOnInit(): void {
      var val = {
        StudID : localStorage.getItem("UserLogin")
      };
      this.service.getStudentbyID(val).subscribe(data=>{
        this.student = data;
        console.log(this.student);
      });
    }
  
  
}

