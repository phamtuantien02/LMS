import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StateService {
readonly APIUrl = "http://localhost:60769/api"

  constructor(private http:HttpClient) { }

  getStateList():Observable<any[]>
  {
    return this.http.get<any>(this.APIUrl+'/State');
  }
  addState(val:any)
  {
    return this.http.post(this.APIUrl+'/State',val);
  }
  updateState(val:any)
  {
    return this.http.put(this.APIUrl+'/State',val);
  }

  deleteState(val:any)
  {
    return this.http.delete(this.APIUrl+'/State/'+val);
  }

  getAllStateNames():Observable<any[]>
  {
    return this.http.get<any[]>(this.APIUrl+'/GetAllStateNames');
  }
}
